export declare const supabase: import("@supabase/supabase-js").SupabaseClient<any, "public", any>;
/**
 * Authentication service for session transfer from SMC Manager
 */
export declare class AuthService {
    /**
     * Get current authentication state
     */
    static getAuthState(): Promise<{
        isAuthenticated: boolean;
        user?: never;
        session?: never;
    } | {
        isAuthenticated: boolean;
        user: {
            id: string;
            email: string | undefined;
        };
        session: import("@supabase/supabase-js").AuthSession;
    }>;
    /**
     * Transfer session from SMC Manager web app
     * This is the key method that enables SSO support
     */
    static transferSessionFromWebApp(): Promise<{
        success: boolean;
        error: string;
        data?: never;
    } | {
        success: boolean;
        data: {
            user: import("@supabase/supabase-js").AuthUser | null;
            session: import("@supabase/supabase-js").AuthSession | null;
        };
        error?: never;
    }>;
    /**
     * Get session from SMC Manager web app
     * This method accesses the web app's localStorage to get the session
     */
    private static getSessionFromWebApp;
    /**
     * Get user's saved SREF codes
     */
    static getUserSavedSREFs(userId: string): Promise<string[]>;
}
/**
 * SREF management service
 */
export declare class SREFService {
    static saveSREF(request: {
        code: string;
        name: string;
        images: string[];
        userId: string;
    }): Promise<{
        success: boolean;
        data: any;
        error?: never;
    } | {
        success: boolean;
        error: string;
        data?: never;
    }>;
}
//# sourceMappingURL=supabase.d.ts.map