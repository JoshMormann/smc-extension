declare class SMCPopup {
    private statusElement;
    private statusTextElement;
    private unauthenticatedDiv;
    private authenticatedDiv;
    private userEmailElement;
    private transferSessionBtn;
    private refreshBtn;
    private transferErrorElement;
    private testPingBtn;
    constructor();
    private initializeElements;
    private setupEventListeners;
    private testConnection;
    private handleTestPing;
    private handleSessionTransfer;
    private showAuthenticatedState;
    private showUnauthenticatedState;
    private setStatus;
    private showTransferError;
    private hideTransferError;
}
//# sourceMappingURL=popup.d.ts.map