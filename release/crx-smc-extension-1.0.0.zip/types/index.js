// Core types for SMC Extension
export {};
//# sourceMappingURL=index.js.map