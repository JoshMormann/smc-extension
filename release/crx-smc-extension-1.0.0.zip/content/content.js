console.log('🚀 SMC: Content script starting...');
// Set global flags to indicate the content script is loaded
window.SMCContentScriptLoaded = true;
window.SMCContentScriptVersion = '1.0.5';
import { SREFScanner } from './sref-scanner';
/**
 * Main content script for SMC Extension
 * Handles SREF scanning on Midjourney pages
 */
class SMCContentScript {
    constructor() {
        console.log('🚀 SMC: Content script class constructor called');
        this.init();
    }
    async init() {
        try {
            console.log('🚀 SMC: Content script initializing...');
            // Set up message listener for background script communication
            chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
                console.log('📨 CONTENT: Received message:', message.type);
                if (message.type === 'TEST_PING') {
                    this.handleTestPing(sendResponse);
                    return true;
                }
                if (message.type === 'SAVE_SREF') {
                    this.handleSaveRequest(message.data, sendResponse);
                    return true;
                }
                console.log('❓ CONTENT: Unknown message type:', message.type);
                sendResponse({ success: false, error: 'Unknown message type' });
                return true;
            });
            console.log('✅ SMC: Content script message listener set up');
            // Test connection to service worker
            await this.testServiceWorkerConnection();
            // Wait for DOM to be ready
            if (document.readyState === 'loading') {
                console.log('📄 SMC: DOM still loading, waiting for DOMContentLoaded...');
                document.addEventListener('DOMContentLoaded', () => this.initializeScanner());
            }
            else {
                console.log('📄 SMC: DOM already ready, initializing scanner...');
                this.initializeScanner();
            }
        }
        catch (error) {
            console.error('❌ SMC: Error in content script init:', error);
        }
    }
    async testServiceWorkerConnection() {
        try {
            console.log('🔔 CONTENT: Testing service worker connection...');
            const response = await chrome.runtime.sendMessage({ type: 'TEST_PING' });
            console.log('🔔 CONTENT: Service worker response:', response);
            if (response.success) {
                console.log('✅ CONTENT: Service worker connection successful');
            }
            else {
                console.log('❌ CONTENT: Service worker connection failed');
            }
        }
        catch (error) {
            console.error('❌ CONTENT: Failed to connect to service worker:', error);
        }
    }
    async handleTestPing(sendResponse) {
        try {
            console.log('🏓 CONTENT: Handling ping request...');
            sendResponse({
                success: true,
                data: {
                    message: 'Content script is alive!',
                    timestamp: new Date().toISOString(),
                    version: '1.0.5'
                }
            });
        }
        catch (error) {
            console.error('❌ CONTENT: Error handling ping:', error);
            sendResponse({ success: false, error: 'Failed to handle ping' });
        }
    }
    async handleSaveRequest(data, sendResponse) {
        try {
            console.log('💾 CONTENT: Handling save request for SREF:', data.code);
            // Mock save operation for now
            await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate API delay
            console.log('✅ CONTENT: Mock save successful for:', data.code);
            sendResponse({
                success: true,
                data: { message: `Mock saved SREF ${data.code} with name: ${data.name}` }
            });
        }
        catch (error) {
            console.error('❌ CONTENT: Error handling save request:', error);
            sendResponse({ success: false, error: 'Failed to save SREF' });
        }
    }
    async initializeScanner() {
        try {
            console.log('🔍 SMC: Initializing SREF scanner...');
            // Initialize the SREF scanner
            this.scanner = new SREFScanner();
            await this.scanner.initialize();
            console.log('✅ SMC: SREF scanner initialized successfully');
        }
        catch (error) {
            console.error('❌ SMC: Failed to initialize SREF scanner:', error);
        }
    }
}
// Initialize content script with error handling
try {
    console.log('🚀 SMC: Creating content script instance...');
    new SMCContentScript();
    console.log('✅ SMC: Content script loaded successfully');
}
catch (error) {
    console.error('❌ SMC: Failed to create content script instance:', error);
}
//# sourceMappingURL=content.js.map