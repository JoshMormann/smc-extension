// Mock data for UI testing
const MOCK_SAVED_SREFS = new Set(['1591269566', '1234567890', '9876543210']);
/**
 * SREF Scanner for Midjourney web app
 * Handles viewport-based detection with scroll optimization
 */
export class SREFScanner {
    constructor() {
        this.indicators = new Map();
        this.processedElements = new Map();
        this.scrollTimeout = 0;
        this.elementsToProcess = new Set();
        this.state = {
            processedElements: new Set(),
            scrollDebounceTimer: 0,
            userSavedCodes: MOCK_SAVED_SREFS, // Use mock data
            isAuthenticated: true, // Mock authentication for UI testing
            isProcessing: false,
        };
        this.initializeIntersectionObserver();
        this.initializeScrollHandling();
    }
    /**
     * Initialize the scanner
     */
    async initialize() {
        console.log('🔍 SMC: Initializing SREF scanner with mock data...');
        console.log('🔍 SMC: Mock saved SREFs:', Array.from(MOCK_SAVED_SREFS));
        // Start scanning visible content
        this.scanVisibleContent();
        console.log('✅ SMC: Scanner ready for viewport-based processing');
    }
    /**
     * Initialize intersection observer for viewport detection
     */
    initializeIntersectionObserver() {
        this.intersectionObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                const element = entry.target;
                if (entry.isIntersecting) {
                    // Element entered viewport - inject spinner immediately
                    this.injectSpinner(element);
                    // Queue for full processing when scroll stops
                    this.elementsToProcess.add(element);
                }
                else {
                    // Element left viewport - update tracking but don't remove indicators
                    const processed = this.processedElements.get(element);
                    if (processed) {
                        processed.isInViewport = false;
                    }
                }
            });
        }, {
            root: null,
            rootMargin: '50px', // Start processing 50px before element enters viewport
            threshold: 0.1,
        });
    }
    /**
     * Initialize scroll handling with debouncing
     */
    initializeScrollHandling() {
        const handleScroll = () => {
            // Clear previous timeout
            clearTimeout(this.scrollTimeout);
            // Mark that we're scrolling (no heavy processing)
            this.state.isProcessing = true;
            // Debounce processing - only process when scroll stops
            this.scrollTimeout = setTimeout(() => {
                this.processQueuedElements();
                this.state.isProcessing = false;
            }, 500);
        };
        // Listen for scroll events
        window.addEventListener('scroll', handleScroll, { passive: true });
        // Also listen for dynamic content changes
        const observer = new MutationObserver(() => {
            // New content appeared - scan for new SREF buttons
            this.scanVisibleContent();
        });
        observer.observe(document.body, {
            childList: true,
            subtree: true,
        });
    }
    /**
     * Scan visible content for SREF codes
     */
    scanVisibleContent() {
        console.log('🔍 SMC: Scanning for new SREF buttons...');
        // Find all SREF buttons
        const srefButtons = document.querySelectorAll('button[title="Style reference"]');
        srefButtons.forEach(button => {
            const element = button;
            // Only start observing elements we haven't seen before
            if (!this.processedElements.has(element)) {
                console.log('🔍 SMC: Found new SREF button, starting observation');
                this.intersectionObserver.observe(element);
                // Mark as tracked but not yet processed
                this.processedElements.set(element, {
                    element,
                    state: 'spinner',
                    srefCode: '',
                    isInViewport: false
                });
            }
        });
    }
    /**
     * Inject lightweight spinner for element entering viewport
     */
    injectSpinner(element) {
        const processed = this.processedElements.get(element);
        if (!processed)
            return;
        // Skip if already has full functionality
        if (processed.state !== 'spinner')
            return;
        console.log('⏳ SMC: Injecting spinner for SREF button');
        // Create lightweight spinner
        const spinner = document.createElement('div');
        spinner.className = 'smc-spinner inline-block ml-1';
        spinner.innerHTML = '⏳';
        spinner.style.cssText = 'font-size: 14px; opacity: 0.7;';
        // Insert after the SREF button
        element.parentNode?.insertBefore(spinner, element.nextSibling);
        // Update state
        processed.isInViewport = true;
    }
    /**
     * Process queued elements when scrolling stops
     */
    processQueuedElements() {
        if (this.elementsToProcess.size === 0)
            return;
        console.log('🔄 SMC: Processing', this.elementsToProcess.size, 'queued elements');
        this.elementsToProcess.forEach(element => {
            this.processElementFull(element);
        });
        this.elementsToProcess.clear();
    }
    /**
     * Process a single element for full SREF detection and functionality
     */
    processElementFull(element) {
        const processed = this.processedElements.get(element);
        if (!processed || processed.state !== 'spinner')
            return;
        // Extract SREF code
        const srefCode = this.extractSREFCode(element);
        if (!srefCode) {
            console.warn('⚠️ SMC: Could not extract SREF code from button');
            return;
        }
        // Extract images from the same container
        const images = this.extractImages(element);
        // Check if user has already saved this SREF
        const isKnown = this.state.userSavedCodes.has(srefCode);
        console.log('🔍 SMC: Processing SREF', srefCode, 'known:', isKnown, 'images:', images.length);
        // Update processed element state
        processed.srefCode = srefCode;
        processed.state = isKnown ? 'full-saved-check' : 'full-save-button';
        // Create detected SREF object
        const detectedSREF = {
            code: srefCode,
            element,
            images,
            isKnown,
            timestamp: Date.now(),
            isProcessed: true,
            isVisible: true,
        };
        // Replace spinner with full indicator
        this.replaceSpinnerWithIndicator(detectedSREF);
    }
    /**
     * Extract SREF code from button element
     */
    extractSREFCode(button) {
        const text = button.textContent;
        // Updated pattern to match actual MidJourney format: --sref 1591269566
        const match = text?.match(/--sref\s+(\d+)/);
        return match?.[1] || null;
    }
    /**
     * Extract image URLs from the same container as the SREF button
     */
    extractImages(button) {
        // Find the parent container that holds both the SREF button and images
        const container = this.findImageContainer(button);
        if (!container)
            return [];
        // Extract all Midjourney image URLs
        const images = Array.from(container.querySelectorAll('img[src*="cdn.midjourney.com"]'))
            .map(img => img.src)
            .filter(src => src.includes('cdn.midjourney.com'));
        return images;
    }
    /**
     * Find the container that holds both SREF button and images
     */
    findImageContainer(button) {
        // Navigate up the DOM to find the main content container
        let current = button;
        while (current && current !== document.body) {
            // Look for the container with the specific grid-cols pattern from MidJourney
            if (current.style.gridTemplateColumns === 'minmax(0,8fr) minmax(0,3fr)') {
                return current;
            }
            current = current.parentElement;
        }
        return null;
    }
    /**
     * Replace spinner with full indicator
     */
    replaceSpinnerWithIndicator(detectedSREF) {
        // Find and remove the spinner
        const spinner = detectedSREF.element.parentNode?.querySelector('.smc-spinner');
        if (spinner) {
            spinner.remove();
        }
        // Create full indicator
        const indicator = this.createIndicatorElement(detectedSREF);
        // Insert after the SREF button
        detectedSREF.element.parentNode?.insertBefore(indicator, detectedSREF.element.nextSibling);
        // Store reference
        this.indicators.set(detectedSREF.code, {
            element: indicator,
            srefCode: detectedSREF.code,
            isKnown: detectedSREF.isKnown,
            isVisible: true,
        });
    }
    /**
     * Create the indicator element
     */
    createIndicatorElement(detectedSREF) {
        const indicator = document.createElement('button');
        if (detectedSREF.isKnown) {
            // Green check for known SREF
            indicator.innerHTML = '✅';
            indicator.className = 'flex-center disabled:pointer-events-none py-1.5 group-button group/button whitespace-nowrap relative min-w-max pointer-events-auto h-7 shrink-0 gap-1.5 cursor-pointer rounded-md font-medium overflow-hidden select-none w-auto px-2 text-xs flex border border-green-500 bg-green-500 text-white';
            indicator.title = 'Already saved to SMC Manager';
        }
        else {
            // Save icon for unknown SREF
            indicator.innerHTML = '💾';
            indicator.className = 'flex-center disabled:pointer-events-none py-1.5 group-button group/button whitespace-nowrap relative min-w-max pointer-events-auto h-7 shrink-0 gap-1.5 cursor-pointer rounded-md font-medium overflow-hidden select-none w-auto px-2 text-xs flex border border-white/50 dark:border-dark-750 shadow-md shadow-black/5 bg-light-50 dark:bg-dark-900 dark:hover:bg-dark-950 hover:bg-white buttonActiveRing text-light-900 backdrop-brightness-150 ring-dark-900! dark:ring-white! transition';
            indicator.title = 'Save to SMC Manager';
            // Add click handler
            indicator.addEventListener('click', () => {
                this.handleSaveClick(detectedSREF);
            });
        }
        return indicator;
    }
    /**
     * Handle save button click
     */
    handleSaveClick(detectedSREF) {
        console.log('💾 SMC: Save clicked for SREF', detectedSREF.code);
        // Create input tooltip
        this.createSaveTooltip(detectedSREF);
    }
    /**
     * Create save tooltip with input field
     */
    createSaveTooltip(detectedSREF) {
        // Remove existing tooltip
        const existingTooltip = document.querySelector('.smc-save-tooltip');
        if (existingTooltip) {
            existingTooltip.remove();
        }
        // Create tooltip container
        const tooltip = document.createElement('div');
        tooltip.className = 'smc-save-tooltip absolute z-50 bg-white dark:bg-dark-900 border border-gray-300 dark:border-dark-750 rounded-md shadow-lg p-3';
        tooltip.style.top = '100%';
        tooltip.style.left = '0';
        tooltip.style.marginTop = '5px';
        // Create input field
        const input = document.createElement('input');
        input.type = 'text';
        input.placeholder = 'Name this SREF';
        input.className = 'w-full px-2 py-1 border border-gray-300 dark:border-dark-750 rounded text-sm bg-white dark:bg-dark-900 text-black dark:text-white';
        // Create save button
        const saveButton = document.createElement('button');
        saveButton.textContent = 'Save';
        saveButton.className = 'mt-2 px-3 py-1 bg-blue-500 text-white rounded text-sm hover:bg-blue-600';
        // Handle save
        const handleSave = async () => {
            const name = input.value.trim();
            if (!name)
                return;
            saveButton.disabled = true;
            saveButton.textContent = 'Saving...';
            // Send save request to background script
            const response = await chrome.runtime.sendMessage({
                type: 'SAVE_SREF',
                data: {
                    code: detectedSREF.code,
                    name,
                    images: detectedSREF.images,
                }
            });
            if (response.success) {
                // Update indicator to green check
                this.updateIndicatorToSaved(detectedSREF.code);
                tooltip.remove();
            }
            else {
                alert('Failed to save SREF: ' + response.error);
                saveButton.disabled = false;
                saveButton.textContent = 'Save';
            }
        };
        saveButton.addEventListener('click', handleSave);
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                handleSave();
            }
        });
        // Add elements to tooltip
        tooltip.appendChild(input);
        tooltip.appendChild(saveButton);
        // Add tooltip to page
        const indicator = this.indicators.get(detectedSREF.code);
        if (indicator) {
            indicator.element.appendChild(tooltip);
            input.focus();
        }
    }
    /**
     * Update indicator to saved state
     */
    updateIndicatorToSaved(srefCode) {
        console.log('✅ SMC: Updating indicator to saved state for SREF', srefCode);
        // Add to mock saved codes
        MOCK_SAVED_SREFS.add(srefCode);
        this.state.userSavedCodes.add(srefCode);
        // Update all indicators for this SREF code
        const indicator = this.indicators.get(srefCode);
        if (indicator) {
            indicator.element.innerHTML = '✅';
            indicator.element.className = 'flex-center disabled:pointer-events-none py-1.5 group-button group/button whitespace-nowrap relative min-w-max pointer-events-auto h-7 shrink-0 gap-1.5 cursor-pointer rounded-md font-medium overflow-hidden select-none w-auto px-2 text-xs flex border border-green-500 bg-green-500 text-white';
            indicator.element.title = 'Already saved to SMC Manager';
            indicator.isKnown = true;
            // Remove click handler by replacing element
            const newElement = indicator.element.cloneNode(true);
            indicator.element.replaceWith(newElement);
            indicator.element = newElement;
        }
        // Update processed element state
        this.processedElements.forEach((processed) => {
            if (processed.srefCode === srefCode) {
                processed.state = 'full-saved-check';
            }
        });
    }
}
//# sourceMappingURL=sref-scanner.js.map