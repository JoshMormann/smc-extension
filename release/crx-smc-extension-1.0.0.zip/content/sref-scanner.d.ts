/**
 * SREF Scanner for Midjourney web app
 * Handles viewport-based detection with scroll optimization
 */
export declare class SREFScanner {
    private state;
    private intersectionObserver;
    private indicators;
    private processedElements;
    private scrollTimeout;
    private elementsToProcess;
    constructor();
    /**
     * Initialize the scanner
     */
    initialize(): Promise<void>;
    /**
     * Initialize intersection observer for viewport detection
     */
    private initializeIntersectionObserver;
    /**
     * Initialize scroll handling with debouncing
     */
    private initializeScrollHandling;
    /**
     * Scan visible content for SREF codes
     */
    private scanVisibleContent;
    /**
     * Inject lightweight spinner for element entering viewport
     */
    private injectSpinner;
    /**
     * Process queued elements when scrolling stops
     */
    private processQueuedElements;
    /**
     * Process a single element for full SREF detection and functionality
     */
    private processElementFull;
    /**
     * Extract SREF code from button element
     */
    private extractSREFCode;
    /**
     * Extract image URLs from the same container as the SREF button
     */
    private extractImages;
    /**
     * Find the container that holds both SREF button and images
     */
    private findImageContainer;
    /**
     * Replace spinner with full indicator
     */
    private replaceSpinnerWithIndicator;
    /**
     * Create the indicator element
     */
    private createIndicatorElement;
    /**
     * Handle save button click
     */
    private handleSaveClick;
    /**
     * Create save tooltip with input field
     */
    private createSaveTooltip;
    /**
     * Update indicator to saved state
     */
    private updateIndicatorToSaved;
}
//# sourceMappingURL=sref-scanner.d.ts.map